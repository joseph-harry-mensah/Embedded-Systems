#include <stdio.h>
#include <wiringPi.h>

#define LONG  500
#define SHORT 100
int pulselength(int len);
int main (void)
{
  wiringPiSetup () ;
  pinMode (0, OUTPUT) ;
  for (;;)
  {
 for(int i= 0; i <3; i++){
 pulselength(SHORT);
 }

for(int i=0; i<3; i++){
pulselength(LONG);
}

for(int i= 0; i<3; i++){
pulselength(SHORT);
}

delay(1000);


  } // main for loop
  return 0 ;
}//int main


int pulselength(int len){

  digitalWrite (0, HIGH) ; delay (len) ;
  digitalWrite (0,  LOW) ; delay (len) ;
  return 0;
}
