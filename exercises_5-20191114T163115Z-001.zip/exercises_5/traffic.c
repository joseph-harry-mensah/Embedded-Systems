#include <stdio.h>
#include <wiringPi.h>


void stage1();
void stage2();
void stage3();
void stage4();

int main (void)
{
  wiringPiSetup () ;
  pinMode (0, OUTPUT) ;
  pinMode (3, OUTPUT) ;
  pinMode (7, OUTPUT) ;
  pinMode (5, OUTPUT) ;
  pinMode (4, OUTPUT) ;
  pinMode (1, OUTPUT) ;

    for (;;)
 {
   while(1)
  {
        void stage1(){
    digitalWrite (1, HIGH)   ;
    digitalWrite (0,  HIGH)  ;
      delay (3000)} 

    void stage2(){
   digitalWrite (4, HIGH)  ;
    digitalWrite (5,  LOW)  ;
    digitalWrite (0, HIGH) ; delay (3000);
}

         void stage3(){
     digitalWrite (5, HIGH) ;
     digitalWrite (7, HIGH); 
       delay (3000);}

 void stage4(){

 digitalWrite (5, HIGH) ;
digitalWrite (3, HIGH) ;
delay (3000) ; }

  }

  return 0 ;

   
}
