/* @file */
/*! @file dht11.h 
*   @brief dht11.h Header file for the DHT11 readout library<br>
*    The DHT11 is a temperature and humidity sensor implementing its
*    own 1-wire serial protocol. The functions of this library allow
*    to start a measurement and to extract human readable results from the
*    serial data stream sent by the DHT11<br>
*    Copyright U. Raich Oct. 2017<br>
*    This program is part of a course on embedded systems held
*    at the University of Cape Coast, Ghana in 2017
*    It is released under the GNU Public License 
*    For details please see https://www.gnu.org/licenses/gpl.html
*/

#ifndef __DHT11_H__
#define __DHT11_H__
#include <stdbool.h>
#include <sys/timeb.h>
#include <time.h>
#include <strings.h>

#define DHT11_GPIO_PIN 0
#define DHT11_PROTOCOL_TIMEOUT     100
#define DHT11_PROTOCOL_SIZE        800
#define DHT11_PROTOCOL_SIZE_MARGIN 200
/* error codes */
#define DHT11_SUCCESS            0
#define DHT11_MISSING_INIT      -1
#define DHT11_NO_MEAS_YET       -2 
#define DHT11_NO_VALID_MEAS_YET -3
#define DHT11_MEM_ALLOC_ERROR   -4
#define DHT11_PROTOCOL_ERROR    -5
#define DHT11_BAD_CHECKSUM      -6
#define DHT11_BAD_TIME_STAMP   -10
/* functions */
void dht11SetDebug(bool);
int  dht11Measurement(void);
void dht11PrintError(int);
void dht11Init(void);
int  dht11GetTemperature(void);
int  dht11GetValidTemperature(void);
int  dht11GetHumidity(void);
int  dht11GetValidHumidity(void);
time_t dht11GetMeasTimeStamp(void);
time_t dht11GetValidMeasTimeStamp(void);
int  dht11GetRawData(int *);
int  dht11GetValidRawData(int *);
int  dht11GetChecksum(void);
int  dht11GetDeviceChecksum();
#endif
