
#include <stdio.h>
#include <stdlib.h>
#include "dht11.h"

int main() {


  int retCode;
  time_t timeStamp;

  printf("# dht11LibTest: Exercising the dht11 library\n");
  printf("# dht11LibTest: Switching debug mode off\n");
  dht11SetDebug(false);
  /*
   * initialize the access library
   */
  dht11Init();

  if ((retCode = dht11Measurement()) < 0) {
    printf("dht11LibTest: Could not make a measurement\n");
    dht11PrintError(retCode);
  }

  /*
    getting at the checksum calculated
  */
  if ((retCode=dht11GetChecksum()) < 0) {
    printf("dht11LibTest: Could not get the checksum\n");
    dht11PrintError(retCode);
  }
  else
    printf("# dht11LibTest: Checksum found is: 0x%02x\n",retCode);
  /*
    getting at the checksum returned by the device
  */

  if ((retCode=dht11GetDeviceChecksum()) < 0) {
    printf("dht11LibTest: Could not get the checksum\n");
    dht11PrintError(retCode);
   }
  else
    printf("# dht11LibTest: Checksum found is: 0x%02x\n",retCode);

  /*
    reading the time stamp of last measurement
  */
  if ((timeStamp = dht11GetMeasTimeStamp()) < 0) {
    printf("dht11LibTest: Could not get valid time stamp\n");
    dht11PrintError((int)timeStamp);
  }
  else
    printf("#  dht11LibTest: Last measurement was made on %s\n",ctime(&timeStamp));


  dht11Init();
  dht11Measurement();
  int temper = dht11GetTemperature();
  printf("The Temperature is %d\n", temper);

  int humid = dht11GetHumidity();
  printf("The Humidity is %d\n", humid);


  return 0;
}
