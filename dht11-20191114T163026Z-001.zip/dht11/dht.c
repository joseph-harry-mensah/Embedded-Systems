#include "CayenneDefines.h"
#include "CayenneWiFi.h"
#include "CayenneWiFiClient.h"
#include <SimpleTimer.h>
#include "DHT.h"

#define CAYANNE_DEBUG
#define CAYANNE_PRINT Serial
#define DHTPIN 5
#define DHTTYPE DHT22   // DHT 22  (AM2302), AM2321

// Cayenne authentication token. This should be obtained from the Cayenne Dashboard.
// Change the value of token, ssid, and pwd to yours
char token[] = "xxxxxx";
char ssid[] = "xxxxxx";
char pwd[] = "xxxxx";
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Cayenne.begin(token, ssid, pwd);
  dht.begin();
}

CAYENNE_OUT(V0)
{
  float t = dht.readTemperature();
  Cayenne.virtualWrite(V0, t); //virtual pin
}

CAYENNE_OUT(V1)
{
  float h = dht.readHumidity();
  Cayenne.virtualWrite(V1, h); //virtual pin
}

void loop() {
  Cayenne.run();
}