/*
 * dht11LibTest: a test program for the functions of the dht11 access 
 * library 
 * copyright U. Raich 2017
 * This program is part of the workshop on embedded systems held at 
 * the University of Cape Coast in the winter semester 2017
 * It has been released under the GNU General Public License
 * see gnu.org/licenses/gpl.html
 */
#include <stdio.h>
#include <stdlib.h>
#include "dht11.h"

int main() {
  int protoData[DHT11_PROTOCOL_SIZE];
  int i,retCode;
  time_t timeStamp;
  
  printf("# dht11LibTest: Exercising the dht11 library\n");
  printf("# dht11LibTest: Switching debug mode off\n");
  dht11SetDebug(false);
  /*
   * initialize the access library
   */
  dht11Init();

  if ((retCode = dht11Measurement()) < 0) {
    printf("dht11LibTest: Could not make a measurement\n");
    dht11PrintError(retCode);
  }
  
  /*
    get at the checksum calculated
  */
  if ((retCode=dht11GetChecksum()) < 0) {
    printf("dht11LibTest: Could not get the checksum\n");
    dht11PrintError(retCode);
  }
  else
    printf("# dht11LibTest: Checksum found is: 0x%02x\n",retCode);
  /*
    get at the checksum returned by the device
  */

  if ((retCode=dht11GetDeviceChecksum()) < 0) {
    printf("dht11LibTest: Could not get the checksum\n");
    dht11PrintError(retCode);
  }
  else
    printf("# dht11LibTest: Checksum found is: 0x%02x\n",retCode);

  /*
    read the time stamp of last measurement
  */
  if ((timeStamp = dht11GetMeasTimeStamp()) < 0) {
    printf("dht11LibTest: Could not get valid time stamp\n");
    dht11PrintError((int)timeStamp);    
  }
  else
    printf("#  dht11LibTest: Last measurement was made on %s\n",ctime(&timeStamp));
  /*
    get at the raw data
  */
  if ((retCode = dht11GetValidRawData(protoData)) < 0) {
    printf("dht11LibTest: Could not get the raw data from the DHT11\n");
    dht11PrintError(retCode);
  }
  else
    for (i=0;i<DHT11_PROTOCOL_SIZE;i++)
      printf("%d\n",protoData[i]);
  return 0;
}
