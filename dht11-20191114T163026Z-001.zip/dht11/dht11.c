/* @file */

/*! @file  dht11.c:
 *  @brief 
 *  A library to access the DHT11 temperature and humidity sensor.
 *  This device uses its own one wire protocol and the library allows to
 *      <list type="bullet">
 *          <item>start a measurement</item>
 *          <item> read the raw data (the bit stream sent by the DHT11)</item>
 *          <item> extract temperature humidity calculated checksum and checksum returned by the device </item>
 *          <item> get the temperature of the last valid measurement (correct checksum) </item>
 *          <item> get the humidity of the last valid measurement (correct checksum) </item>
 *          <item> get the time stamp of the last valid measurement </item>
 *      </list>
 *  Copyright U. Raich Oct. 2017<br>
 *  This program is part of a course on embedded systems held
 *  at the University of Cape Coast, Ghana in 2017<br>
 *  It is released under the GNU Public License.
 *  <br>
 *  For details please see https://www.gnu.org/licenses/gpl.html<br>
 *  @author Uli Raich
 */

#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include "dht11.h"

static bool dht11Debug = false;
static int protoData[DHT11_PROTOCOL_SIZE+DHT11_PROTOCOL_SIZE_MARGIN];
static int validProtoData[DHT11_PROTOCOL_SIZE];
static struct timeb lastMeas;
static struct timeb lastValidMeas;
static short temperature,validTemperature, humidity, validHumidity;
static int checksum, deviceChecksum;
static bool initDone=false;

static int dht11Evaluate();

/*! @brief
 *  switches debug mode on or off
 *  @param onOff true: switches debug mode on<br>
 *               false: switches debug mode off
 */ 
void dht11SetDebug(bool onOff) {
  dht11Debug = onOff;
}
/*! @brief
 *  prints an error message in human understandable form
 *  @param an error code returned by the library
 */
void dht11PrintError(int err) {
  switch(err) {
  case DHT11_SUCCESS:
    printf("dht11 library call returned successfully\n");
    break;
  case DHT11_MISSING_INIT:
    printf("dht11Init was not called before attempting to make a measurement\n");
    break;
  case DHT11_NO_MEAS_YET:
    printf("dht11 library: No measurement was made yet\n");
    break;
  case DHT11_NO_VALID_MEAS_YET:
    printf("dht11 library: No valid measurement was made yet\n");
    break;
  case DHT11_MEM_ALLOC_ERROR:
    printf("dht11 library: Could not allocate enough memory to hold the data\n");
    break;
  case DHT11_PROTOCOL_ERROR:
    printf("dht11 library: Protocol error: the data stream was probably not read entirely\n");
    break;
  case DHT11_BAD_CHECKSUM:
    printf("dht11 library: Checksum error on protocol data\n");
    break;
  case DHT11_BAD_TIME_STAMP:
    printf("dht11 library: The time stamp was invalid\n");
    break;
  default:
    printf("dht11 library: Unknown error code\n");
    break;
  }
}
/*! @brief
 *  connects to the wiringPi library
 */
void dht11Init() {
  wiringPiSetup();
  /*
    clear out the time stamps
  */
  bzero(&lastMeas,sizeof(struct timeb));
  bzero(&lastValidMeas,sizeof(struct timeb));
  initDone = true;
}
/*! @brief
 *  make a measurement and saves the data in an internal array
 *  returns DHT11_SUCCESS if successful
 *          DHT11_MISSING_INIT if dht11Init has not been called before
 */
int dht11Measurement() {
  int i,*dataPtr;
  
  if (!initDone)
    return (DHT11_MISSING_INIT);
  pinMode(DHT11_GPIO_PIN,OUTPUT);

  /*
   * we print out the data in a format that gnuplot can use for plotting
   * The # tells gnuplot that this line is a comment
   */ 
  if (dht11Debug) 
    printf("#Raspberry Pi read DHT11 protocol\n");
  /* start the dht11 by pulling the data line down for 18 ms 
     and then high for 18 us
  */
  dataPtr = protoData;
  digitalWrite(DHT11_GPIO_PIN,0);
  delay(18);
  digitalWrite(DHT11_GPIO_PIN,1);
  delayMicroseconds(40);

  /* switch the GPIO pin to input and read the data every 5 us */
  pinMode(DHT11_GPIO_PIN,INPUT);
  for (i=0;i<800;i++){
    *dataPtr++ = digitalRead(DHT11_GPIO_PIN);
    delayMicroseconds(5);
  }
  /* get the time stamp */
  if (ftime(&lastMeas) < 0)
    return DHT11_BAD_TIME_STAMP;
  if (dht11Debug) {
    dataPtr = protoData;
    for (i=0;i<800;i++)
      printf("%d\n",*dataPtr++);
  }
  /*
    evaluate the data and check if things worked ok
  */
  if (dht11Evaluate() == DHT11_SUCCESS) {
    bcopy(&lastMeas, &lastValidMeas, sizeof(struct timeb));
    validTemperature = temperature;
    validHumidity    = humidity;
    bcopy(protoData,validProtoData,DHT11_PROTOCOL_SIZE*sizeof(int));
  }
  return DHT11_SUCCESS;
}

/*
 * readBit reads a single bit from the DHT11 data stream.
 */
static int readBit(int **data) {
  int retVal,*dataPtr=*data;
  int counter;
  /* wait for the signal to go high again */
  counter = 0;
  /*
  if(debug)
    printf("readBit: pointer to data: 0x%lx\n",(long)dataPtr);
  */
  while(!(*dataPtr)) {
    /*
    if (debug) {
      printf("readBit: dataPtr: 0x%lx *dataPtr: %d\n",(long)dataPtr,*dataPtr);
      printf("readbit: end of protoData: 0x%lx\n",(long)&protoData[999]);
    }
    */
    dataPtr++;    
    counter++;
    if (counter > DHT11_PROTOCOL_TIMEOUT) 
      return (DHT11_PROTOCOL_ERROR);
  }
    /* 
     now look 3 samples further (30 us) on if the pulse is still high
     in which case we have a 1
     else we have a 0
  */
  if (*(dataPtr+5) == HIGH)
    retVal = HIGH;
  else
    retVal =  LOW;
  counter = 0;
  while(*dataPtr) {  /* wait until the signal goes low and the high again */
    /*
    if (debug) {
      printf("readBit: dataPtr: 0x%lx *dataPtr: %d\n",(long)dataPtr,*dataPtr);
      printf("readbit: end of protoData: 0x%lx\n",(long)&protoData[999]);
    }
    */
    dataPtr++;
    counter++;
    if (counter > DHT11_PROTOCOL_TIMEOUT)
      return (DHT11_PROTOCOL_ERROR);
  }
  counter = 0;
  while(!(*dataPtr)) {/* now we are ready to read the next bit */
    /*
    if (debug) {
      printf("readBit: dataPtr: 0x%lx *dataPtr: %d\n",(long)dataPtr,*dataPtr);
      printf("readbit: end of protoData: 0x%lx\n",(long)&protoData[999]);
    }
    */
    dataPtr++;
    counter++;
    if (counter > DHT11_PROTOCOL_TIMEOUT)
      return (DHT11_PROTOCOL_ERROR);
  }
  *data = dataPtr; 
  return retVal;
}

/*
 * evaluate tries to extract the values for temperature and humidity from 
 * the protoData which was filled by measure
 * It tests if the checksum is correct an returns 
 */
static int dht11Evaluate() {
  //  int *writePtr;
  int *readPtr,tmp;
  int finalData[5],nextBit;
  int i,j,sum;
    
  /* Now we have to interpret the pulse train */
  /*
  if (debug) {
    printf("dht11Evaluate: protocol data:\n");
    readPtr = protoData;
    for (i=0;i<800;i++)
      printf("%d\n",*readPtr++);
  }
  */
  readPtr = protoData;

  /* 
   *  the protocol header is 80us low (of which only part is seen because
   *  we call the library ro switch the gpio pin from output to input)
   *  followed by 80 us high
   */ 
  while (!(*readPtr++)) ; /* wait until the pulse is high */
  while (*readPtr++) ;    /* wait until it goes high again */
  /*
  while (!(*readPtr))
    printf("%d ",*readPtr++);
  printf("\nbit is high\n");
  while (*readPtr)
    printf("%d ",*readPtr++);
  printf("\nbit is low\n");
  */
  if (dht11Debug)    
    printf("dht11Evaluate: after header\n"); 
  for (i=0; i<5;i++) {
    tmp = 0;
    for (j=0;j<8;j++) {
      tmp = tmp << 1;
      /*
      if (debug)
	printf("dht11Evaluate: data pointer before call: %lx\n",(long)readPtr);
      */
      if ((nextBit=readBit(&readPtr)) < 0 ) {
	  printf("Protocol error!\n");
	  return (nextBit);
	}
	else
	  tmp |= nextBit;
      /*
      if (debug)
	printf("dht11Evaluate: data pointer after call: 0x%lx\n",(long)readPtr);
      */
    }
    finalData[i]=tmp;
    /*
    if (debug)
      printf("dht11Evaluate: finalData[%d]: 0x%02x\n",i,tmp);
    */
  }
  sum = 0;
  for (i=0;i<4;i++) {
    if (dht11Debug) 
      printf("Data extracted: %x\n",finalData[i]);
    sum += finalData[i];
  }
  temperature = finalData[2];
  humidity    = finalData[0];
  checksum = sum;
  deviceChecksum = finalData[4];
  if (dht11Debug) {
    printf("Checksum calculated: 0x%x, checksum read: 0x%x\n",checksum,deviceChecksum);
    printf("Temperature: %d.%d\n",finalData[2],finalData[3]);
    printf("Humidity: %d.%d\n",finalData[0],finalData[1]);
  }

  if (sum != finalData[4])
    return (DHT11_BAD_CHECKSUM);
  else
    return(DHT11_SUCCESS);
}
/*! @brief
 *  returns the measured temperature value in degrees C
 *  @return The last temperature measured independent of the checksum result
 *          System interrupts may disturb reading of the data stream from the 
 *          DHT11 and corrupt the data. This is checked for by comparing the 
 *          calculated checksum with the one sent by the DHT11.
 *          This call returns the temperature data without the checksum test.
 */ 
int dht11GetTemperature() {
  if (lastMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else
    return(temperature);
}
/*! @brief
 *  returns the measured temperature value in degrees C
 *  @return The last temperature measured with correct checksum
 *          this returns valid temperature data
 */ 
int dht11GetValidTemperature() {
  if (lastValidMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else
    return(validTemperature);
}
/*! @brief
 *  returns the measured humidity value in %
 *  @return The last humidity data measured independent of the checksum result
 *          System interrupts may disturb reading of the data stream from the 
 *          DHT11 and corrupt the data. This is checked for by comparing the 
 *          calculated checksum with the one sent by the DHT11.
 *          This call returns the humidity data without the checksum test.
 */ 
int dht11GetHumidity() {
  if (lastMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else
    return(humidity);
}
/*! @brief
 *  returns the measured humidity value in %
 *  @return The last temperature measured with correct checksum
 *          this returns valid temperature data
 */ 
int dht11GetValidHumidity() {
  if (lastValidMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else
    return(validHumidity);
}
/*! @brief
 *  returns the time stamp of the last measurement
 *  @return The time stamp  independent of the checksum test
 */ 
time_t dht11GetMeasTimeStamp(){
  if (lastMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else
    return lastMeas.time;
}
/*! @brief
 *  returns the time stamp of the last valid measurement
 *  @return The time stamp of the last measurement having passed the 
 *          checksum test. You can print the time stamp in a humanly
 *          readable format with:<br> 
 *          timeStamp = dht11GetMeasTimeStamp();<br>
 *          printf("%s\n",ctime(&timeStamp));
 */ 
time_t dht11GetValidMeasTimeStamp(){
  if (lastValidMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else  
    return lastValidMeas.time;
}
/*! @brief
 *  returns the measured data independent of the checksum test
 *  @param int *rawData is a pointer to an integer array of a size of at least 
 *         DHT11_PROTOCOL_SIZE integer values.
 *         If a NULL pointer is passed to the routine, it will allocate memory
 *         space big enough to hold the data. In this case the caller must free
 *         the allocated memory after use
 */ 
int  dht11GetRawData(int *rawData) {
  if (lastMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  
  if (rawData == NULL) {
    if (calloc(DHT11_PROTOCOL_SIZE,sizeof(int)) == NULL)
      return(DHT11_MEM_ALLOC_ERROR);
  }
  bcopy(protoData,rawData,DHT11_PROTOCOL_SIZE*sizeof(int));
  return DHT11_SUCCESS;
}
/*! @brief
 *  returns the measured data which were checked by the checksum test
 *  @param int *rawData is a pointer to an integer array of a size of at least 
 *         DHT11_PROTOCOL_SIZE integer values.
 *         If a NULL pointer is passed to the routine, it will allocate memory
 *         space bit enough to hold the data. In this case the caller must free
 *         the allocated memory after use
 */ 

int  dht11GetValidRawData(int *rawData) {
  if (lastValidMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  
  if (rawData == NULL) {
    if (calloc(DHT11_PROTOCOL_SIZE,sizeof(int)) == NULL)
      return(DHT11_MEM_ALLOC_ERROR);
  }
  bcopy(validProtoData,rawData,DHT11_PROTOCOL_SIZE*sizeof(int));
  return DHT11_SUCCESS;
}
/*! @brief
 *  returns the checksum as calculated from the data
 */ 
int dht11GetChecksum() {
  if (lastMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else {  
    if (dht11Debug)
      printf("dht11GetChecksum: returning the checksum: 0x%02x\n",
	     checksum);
    return(checksum);
  }
}

/*! @brief
 *  returns the checksum as read from the dht11
 */ 
int dht11GetDeviceChecksum() {
  if (lastMeas.time == 0)
    return(DHT11_NO_VALID_MEAS_YET);
  else  {
    if (dht11Debug)
      printf("dht11GetDeviceChecksum: returning the device checksum: 0x%02x\n",
	     deviceChecksum);
    return(deviceChecksum);
  }
}
